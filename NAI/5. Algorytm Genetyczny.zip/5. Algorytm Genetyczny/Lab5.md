# Lab 5

## Zadanie 1
Przygotuj większy przykład problemu plecakowego - ma być 15 elementów. Upewnij się, że nie wszystkie się zmieszczą, ale co najmnie 3 wejdą do plecaka. Uruchom dla populacji rozmiaru 100 oraz 50 iteracji.

## Zadanie 2
Zaimplementować funkcję mutacji. 

## Zadanie 3
Dodać parametry od których będzie zależeć prawdopodobieństwo krzyżowania i mutacji.