import random


def select_roulette_rule(fitnesses):
    sum_fit = 0
    selected = []
    for f in fitnesses: sum_fit += f
    for i in range(len(fitnesses)):
        r = random.random()*sum_fit
        sf = 0
        for j in range(len(fitnesses)):
            f = fitnesses[j]
            sf+=f
            if sf>r:
                selected.append(j) # append index of individual
                break
    return selected


def crossover(a,b):
    cross_point = random.randint(0,len(a)-1)
    new_a = [ a[i] if i < cross_point else b[i] for i in range(len(a)) ]
    new_b = [ b[i] if i < cross_point else a[i] for i in range(len(a)) ]
    return new_a, new_b


def genetic_algorithm(fitness, random_solution, iterations, pop_size):
    population = [ random_solution() for _ in range(pop_size) ]

    for i in range(iterations): 
        fitnesses = [ fitness(population[i]) for i in range(len(population)) ]
        print("f:", fitnesses)
        selected = select_roulette_rule(fitnesses)
        print("  ", selected)
        new_population = []
        for i in range(int(len(population)/2)):
            a,b = crossover(population[selected[i*2]],population[selected[i*2+1]])
            new_population.append(a)
            new_population.append(b)
        # todo: mutation and probabilities of mutation and crossover
        population = new_population
    return population


def random_packing(n):
    return [ random.randint(0,1) for _ in range(n) ]


def value_knapsack(knapsack, packing ):
    """Function calculating knapsack value"""
    value = 0
    weight = 0
    for i,item in enumerate(knapsack['items']):
        value += item['value'] if packing[i] == 1 else 0
        weight += item['weight'] if packing[i] == 1 else 0
        if weight > knapsack['capacity']:
            return 0
    return value


def main():
    knapsack = {
        "capacity": 10,
        "items":[{"weight":1,"value":2}, {"weight":2,"value":3},
                 {"weight":5,"value":6}, {"weight":4,"value":10}]
    }
    genetic_algorithm(lambda x: value_knapsack(knapsack, x ),
                      lambda: random_packing(len(knapsack['items'])),
                      10,
                      10)


if __name__ == "__main__":
    main()